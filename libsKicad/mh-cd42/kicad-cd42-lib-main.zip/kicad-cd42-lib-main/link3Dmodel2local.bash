ln -sr ./grabcad/MH-CD42.step $HOME/.local/share/kicad/6.0/3dmodels
